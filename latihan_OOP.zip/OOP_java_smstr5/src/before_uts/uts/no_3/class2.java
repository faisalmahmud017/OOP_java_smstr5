package before_uts.uts.no_3;

public class class2 {
    int jml1 = 500, jml2 = 320, hasil;
    int jumlah;
    String nvr;


    void phasesatu(){
        jumlah = 500;
        nvr = "NVR1,NVR2,NVR3";
        System.out.println("Jumlah CCTV Phase 1 adalah : " + jumlah);
        System.out.println("Berikut beberapa NVR yang termasuk : "+nvr);
    
    }
}