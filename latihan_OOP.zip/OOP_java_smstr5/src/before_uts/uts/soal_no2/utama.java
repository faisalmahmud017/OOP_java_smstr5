package before_uts.uts.soal_no2;

public class utama {

    public static void main(String [] args) {
        transaksi data=new transaksi();

        data.pilihan_kamar();
    }
}