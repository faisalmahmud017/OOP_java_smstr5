package before_uts.latihan_pert3;

public class belajarmodifier1 {
    public String nama;
    public double gaji;
}

