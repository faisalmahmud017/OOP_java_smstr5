package before_uts.latihan_pert3;

public class belajarmodifier3 {
    public double nilai1,nilai2;

    double getTambah() {
        double hasil = this.nilai1+this.nilai2;
        return hasil;
    }
}