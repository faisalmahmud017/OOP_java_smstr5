package before_uts.latihan_pert3;

public class belajarmodifier2 {
    private String nama;
    private double gaji;
    
}