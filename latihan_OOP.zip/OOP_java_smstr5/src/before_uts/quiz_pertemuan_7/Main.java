package before_uts.quiz_pertemuan_7;

public class Main {
    public static void main(String [] args) {

    order_ojol orderan= new order_ojol();
        orderan.cetak();
        
    }
}