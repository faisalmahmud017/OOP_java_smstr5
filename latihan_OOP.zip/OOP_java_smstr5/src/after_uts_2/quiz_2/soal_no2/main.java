package quiz_2.soal_no2;

public class main {
    
}
