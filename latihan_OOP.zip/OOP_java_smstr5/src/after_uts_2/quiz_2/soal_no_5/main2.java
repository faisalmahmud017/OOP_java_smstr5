package quiz_2.soal_no_5;


public class main2 extends Karyawan {

    void panggil() {
		super.masukKerja();
    }
    
    
       
    
    
    public static void main(String[] args) {
        Karyawan dosen = new Karyawan();
        dosen.masukKerja();
        
        // main2 nam = new main2();
        
        
        
		
	}
    
}
