package quiz_2.soal_no_5;


public class Dsn extends Karyawan {

	public Dsn () {
		super();
	}

	

}