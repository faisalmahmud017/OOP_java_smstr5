package quiz_2.soal_no_4;

public class karyawan {
    int Gol_A,Gol_B,Gol_C;
}
