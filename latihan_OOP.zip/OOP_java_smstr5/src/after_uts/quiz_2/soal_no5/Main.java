package quiz_2.soal_no_5;

public class Main {
	public static void main(String[] args) {
		Dsn dosen = new Dsn();
		dosen.masukKerja();
		

		
	}
}