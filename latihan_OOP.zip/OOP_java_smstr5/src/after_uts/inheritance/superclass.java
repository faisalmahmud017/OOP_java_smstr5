// package after_uts.Superclass;

public class superclass {
    public void jenis_tumbuhan() {
        System.out.println("jenis tumbuhan yang berkembang secara vegetatif");
        System.out.println("1. Umbi Lapis");
        System.out.println("2. Tunas");
        System.out.println("3. Rizoma");
        System.out.println("4. Geragih");
        System.out.println("");
    }


    public static void main(String [] args) {
        superclass sc = new superclass();

        sc.jenis_tumbuhan();


    }
    
}